
kalori_dict = {
    'Anchovies': 60,
    'Boiled-Egg': 78,
    'Cah Kangkung': 40,
    'Chicken Nugget': 45,
    'Chicken Rendang': 250,
    'Crispy Fried Chicken': 280,
    'Cucumber': 8,
    'Fried-Chicken': 250,
    'Fried-Egg': 90,
    'Mie Ayam': 350,
    'Mie Bakso': 400,
    'Peanuts': 68,
    'Rendang': 300,
    'Rice': 200,
    'Sambal': 30,
    'Telur Balado': 120,
    'Tempe Goreng': 120,
    'curry': 180
}
